import { getCountdown } from "../src/client/js/getCountdown";

describe("Testing countdown", () => {
    test("Test getCountdown", () => {
        const inDate = new Date("11/20/2020");
        // Expected outcome will change each day since it compares to current date
        expect(getCountdown(inDate)).toEqual(4);
    })
})