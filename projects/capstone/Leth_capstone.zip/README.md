# Weather-Journal App Project

## Overview
This app calls 3 apis and updates the UI based on the input.

## Notes
For testing, you may need to change the dates on the sample inputs since the countdown function uses the current date as a reference.

City name, start date, and end date are required inputs. Country and state are optional.
